<?php
include 'auth/connection.php';
$sql="SELECT * FROM  sonu";
$result = $con->query($sql);
$output = array();
while($row = $result->fetch_assoc()) {
   $output[]=$row;
  }
$output=json_encode($output);
echo $output;


?>