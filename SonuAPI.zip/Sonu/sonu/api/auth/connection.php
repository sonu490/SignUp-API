<?php
$con= new mysqli("sql309.epizy.com","epiz_31937350","0KqOESMEc75DCo7","epiz_31937350_project");
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}

?>