<?php
$name=$_GET['namee'];
$email=$_GET['emaill'];
$mobile=$_GET['numberr'];
$password=$_GET['passwordd'];
echo $name.' -- '.$email.' -- '.$mobile.' -- '.$password;
if($name=='' || $email=='' || $mobile=='' || $password==''){
    header("location:http://sonusharma.rf.gd/sonu");
}
include 'auth/connection.php';
$sql="INSERT INTO `sonu` (`name`, `email`, `mobile`, `password`) VALUES ('$name', '$email', '$mobile', '$password')";
if ($con->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
header("location:http://sonusharma.rf.gd/sonu");

?>