<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calling app</title>
</head>
<body>
<form action='api/insert.php' method='get'>
    <label for="name">Enter Name</label>
    <input type="text" name="namee" id="namee" required><br>
    <label for="email">Enter Email</label>
    <input type="email" name="emaill" id="emaill" required><br>
    <label for="name">Enter Number</label>
    <input type="tel" name="numberr" id="numberr" required><br>
    <label for="name">Enter Password</label>
    <input type="password" name="passwordd" id="passwordd" required><br>
    <input type="submit">
    <button type='button' onclick="loadd()">Show Data</button>
</form>
    <div style="border:2px black solid" >
        <p id="idd"></p>
    </div>
</body>
<script>
    function loadd(){
        var tableData='<table style="width:100%;border:2px solid red;"><tr><td><b>Name</b></td><td><b>Email</b></td><td><b>Mobile</b></td><td><b>Password</b></td></tr>';
        fetch("http://sonusharma.rf.gd/sonu/api/allData.php").then(response=>response.json()).then(data=>{
            if(data.length==0){
                alert("Wrong Username");
                document.getElementById("idd").innerHTML="No Contact";
            }
            else{
                for(var i=0;i<data.length;i++){
                    console.log(data[i].name);
                tableData=tableData+'<tr><td>'+data[i].name+'</td><td>'+data[i].email+'</td><td>'+data[i].mobile+'</td><td>'+data[i].password+'</td><td></tr>';
            }
            tableData=tableData+"</table>";
            document.getElementById("idd").innerHTML=tableData;
            }
            
        });
    }
</script>
</html>